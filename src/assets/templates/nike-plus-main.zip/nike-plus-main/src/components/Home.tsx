export const Home = () => {
  return <>Home</>;
};
