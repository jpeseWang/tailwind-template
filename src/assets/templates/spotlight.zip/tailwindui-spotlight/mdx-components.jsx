export function useMDXComponents(components) {
  return {
    ...components,
  }
}
